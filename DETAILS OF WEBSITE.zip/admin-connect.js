(()=>{document.querySelectorAll('.account-action').forEach(el=>{el.addEventListener('click',e=>{e.preventDefault();e.stopImmediatePropagation();location.href='/login';},true);});})();
